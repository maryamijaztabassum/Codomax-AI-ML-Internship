# Module 3 — Data Analysis & Visualization

**Internship Project**

## Project Overview
This project demonstrates a basic data-analysis workflow using Python. It uses a sample sales dataset and covers dataset loading, exploration, data cleaning, analysis, and visualization.

## Technologies Used
- Python
- Pandas
- NumPy
- Matplotlib
- Google Colab / Jupyter Notebook

## Project Tasks
- Load and explore a dataset
- Identify and handle missing values
- Remove duplicate records
- Perform basic statistical analysis
- Analyze sales by category and region
- Create a bar chart
- Create a line chart
- Create a pie chart

## Files
- `Data_Analysis_Visualization.ipynb` — Complete notebook
- `sales_dataset.csv` — Sample sales dataset
- `README.md` — Project documentation

## How to Run
1. Open the notebook in Google Colab or Jupyter Notebook.
2. Upload `sales_dataset.csv` if using Google Colab.
3. Run the cells from top to bottom.
4. Review the generated analysis and charts.

## Learning Outcome
The project demonstrates the complete basic data-analysis workflow:

**Loading → Exploring → Cleaning → Analyzing → Visualizing**

## Internship Module
**Module 3: Data Analysis & Visualization**
